package co.edu.umanizales.tads;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TadsApplicationTests {

    @Test
    void contextLoads() {
    }

}
